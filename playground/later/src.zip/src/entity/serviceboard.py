

class Serviceboard:

    def __init__(self, service: str):
        self.service = service

