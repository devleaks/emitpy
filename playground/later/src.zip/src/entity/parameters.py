import os

HOME = "."
DATA_DIR = os.path.join(HOME, "..", "data")