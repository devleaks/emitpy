from flight import Flight
from parking import Parking


class Rotation:

    def __init__(self, arrival: Flight, departure: Flight, parking: Parking, schedule: str):
        self.service = service

