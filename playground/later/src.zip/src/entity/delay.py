

class Delay:

    def __init__(self, newdatetime: str, delaycode: str):
        self.newdatetime = newdatetime
        self.delaycode = delaycode

