from .airport import ManagedAirport
from .airline import Airline
import logging

logging.basicConfig(level=logging.DEBUG)  # filename=('FTG_log.txt')


class Flightboard:

    def __init__(self, airport: ManagedAirport):
        self.manageairport = airport
        self.airports = {}
        self.airlines = {}




"""
Algorithm


1. Load environment

1.1 Load simulation Parameters

        Slot time. If none, no slotted time, time is totally arbitrary.
        Flight density is number of mouvement per hour.
        Maximum capacity per runway is #slot/hour / 2 (departure or arrival) if no contengency.

        We can imagine a "density per hour": [2, 4, 8, 22, 17... ] 24 values for each hour of the day.
        We can even imagine a density type: PAX or CARGO per hour: [[2, 8], [0, 6], [20, 2]...]

    (check consistency of parameters, for ex. 24 density per day, etc.)

1.2 Load airports

1.2.1 Load ManagedAirport
  - Separate runways for departure and arrival?
  - Runway time slotted? If yes, make slots.

  - Set QFU, etc.

1.2.2 Load other airports
  - Load from global airport database.
  - If other airport has detail, create details, otherwise create normal.


2. Build a set of arrival and departure times.

  2.1 To do later: Allow for planes on the ground (already arrived). Schedule them for departure only.
                   First departure is at or after start time of simulation.
                   Determine all times of departure (occupied slots).
                   SCHEDULED time is 30 minutes (parameter) before time of slot, rounded (FLOOR!) to 5~10 minutes for display.
                   I.e. slot = 15:23, SCHEDULED(displayed)= 14:53 rounded to 14:50.

  2.2. First arrival is at or after start time of simulation (i.e. plane may fly in __before__ the start time of the simulation.)


    For each hour in simulation:

        Depending on density, pickup arrival slots in current hour.
        I.e. if density = 20 mvts per hour, schedule 10 arrivals.
        (At beginning of simulation, there will be less movement, since no departure.
        At end of simulation too, since only departure, no more arrival.)


        For this hour: Loop either for number of flights or "until" end datetime is reached:

            Determine if PAX or CARGO (How? from density?)
            Pickup slot/time for arrival. Round time to 5 minutes (parameter).
            Is at least one slot or "time interval"(parameter) after previous one.
            Depends on "density" of flight. Density of flights expressed in % of max capacity. Max capacity = #runways * 6

            Pickup airport source at some distance for arrival.
            Pickup airline (from managed airport or remote airport if available).
            Pickup plane for distance.
            Pickup parking suitable for plane, may be dependant on PAX/CARGO and airline (favorite apron/gates)

            Pickup airport destination at about same distance for departure.
            Set "global" rotation duration, function of aircraft size.
            Set departure time at least (total_rotation_duration * (coefficient(parameter) > 1.0)) after arrival. Add random time (parameter).
            Pickup next avaialble departure slot/time.



3. (Optional) From set of arrival/departure, build rotations

  Schedule rotation services.
  Attempt to use queue for service vehicle.


At the end of this first phase, we have a formal schedule for arrivals, departures,
and service of planes during rotation.


"""
