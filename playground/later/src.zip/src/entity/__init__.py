__VERSION__ = '0.1'
__NAME__ = "emitpy"
__DESCRIPTION__ = "Flight path generator."


from .airport import Airport, DetailedAirport, ManagedAirport
from .aircraft import Aircraft
from .location import Location
from .geo import Point, Line

from .parameters import DATA_DIR
