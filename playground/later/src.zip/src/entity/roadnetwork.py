from geojson import LineString


class Roads:

    def __init__(self, name: str, segments: [LineString]):
        pass
