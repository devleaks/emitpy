"""
An Aircraft is a passenger or cargo plane.
"""
from airline import Airline
from identity import Identity

from constants import AIRCRAFT, PAX, CARGO


class AircraftModel:
    """
    ICAO

    Horizontal speeds (knots):
    staxi
    stakeoff
    sclimb
    scruise
    sdescend
    sfinal
    sapproach
    slanding

    Vertical speeds (feet per min):
    initial_climb
    climb
    descend
    descend_expedite
    approach
    final

    passenger capacity=150 or [100,20,10]
    cargo capacity
    fuel capacity

    mtow?

    range(nm)

    airlines
    alike

    length
    width
    icao_category=[A-F]


    "simulation size factor": A320=1, A350=1.8, etc.
    """

    def __init__(self, icao: str, manufacturer: str):

        self.icao = icao
        self.manufacturer = manufacturer


class Aircraft(Identity):

    def __init__(self, operator: Airline, acModel: AircraftModel, registration: str, cargo: bool = False):
        ty = CARGO if cargo else PAX
        Identity.__init__(self, operator.name(), AIRCRAFT, ty, registration)  # {aircraft:pax|aircraft:cargo}
        self.aircraft_model = acModel
