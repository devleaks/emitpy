from resource import Resource

class Reservation:

    def __init__(self, resource: Resource, datefrom: str, dateto: str):
        pass


