"""
An Airline is an operator of Flight movements with an Aircraft
"""
from .company import Company
from .airport import Airport
from .aircraft import Aircraft

from .constants import AIRLINE, PAX


class Airline(Company):

    def __init__(self, name: str, airports: [Airport], aircrafts: [Aircarft]):
        Company.__init__(self, name, AIRLINE, PAX, name)
        self.airports = airports
        self.aircrafts = aircrafts


