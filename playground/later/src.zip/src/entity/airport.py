"""
Different types of airports, depending on their status in the simulation.

- Airport: Regular destination
- DetailedAirport: Destination with some added information (airlines)
- ManagedAirport: Main airport in simulation.

"""
from .location import Location
from .parameters import DATA_DIR
from .airline import Airline
import yaml

AIRPORT_DATABASE = "airports"

""" ***************************************************************************

An airport is a location for flight departure and arrival.

    *********************************************************************** """
class Airport(Location):

    def __init__(self, icao: str, iata: str, name: str, city: str, country: str, region: str, lat: float, lon: float, alt: float):
        """
        Constructs a new instance.

        :param      icao:     The icao
        :type       icao:     str
        :param      iata:     The iata
        :type       iata:     str
        :param      name:     The name
        :type       name:     str
        :param      city:     The city
        :type       city:     str
        :param      country:  The country
        :type       country:  str
        :param      lat:      The lat
        :type       lat:      float
        :param      lon:      The lon
        :type       lon:      float
        :param      alt:      The alternate
        :type       alt:      float
        """
        Location.__init__(self, name, city, country, lat, lon, alt)
        self.icao = icao
        self.iata = iata
        self.region = region


    @staticmethod
    def load(name):
        """
        Loads airport definition from YAML file

        :param      name:  Airport ICAO
        :type       name:  { str }

        Returns an Airport object or None
        """
        fn = os.path.join(DATA_DIR, AIRPORT_DATABASE, name)
        file = open(fn, "r")
        a = yaml.load(file, Loader=yaml.FullLoader)
        file.close()
        return Airport(icao=a.icao, iata=a.iata, name=a.name, city=a.city, country=a.country, lat=a.lat, lon=a.lon, alt=a.alt)


""" ***************************************************************************
An DetailedAirport is an airport for which we manager more details like operating airlines.
    *********************************************************************** """


class DetailedAirport(Airport):

    def __init__(self, icao: str, iata: str, name: str, city: str, country: str, region: str, lat: float, lon: float, alt: float):
        """
        Constructs a new instance.

        :param      icao:     The icao
        :type       icao:     str
        :param      iata:     The iata
        :type       iata:     str
        :param      name:     The name
        :type       name:     str
        :param      city:     The city
        :type       city:     str
        :param      country:  The country
        :type       country:  str
        :param      lat:      The lat
        :type       lat:      float
        :param      lon:      The lon
        :type       lon:      float
        :param      alt:      The alternate
        :type       alt:      float
        """
        Airport.__init__(self, icao, iata, name, city, country, region, lat, lon, alt)
        self.runways = {}
        self.airlines = {}


    def loadAirlines(self):
        pass


    @staticmethod
    def loadSingle(name):
        """
        Loads a detailed airport definition from YAML file

        :param      name:  Airport ICAO
        :type       name:  { str }

        Returns an Airport object or None
        """
        fn = os.path.join(DATA_DIR, AIRPORT_DATABASE, name)
        file = open(fn, "r")
        a = yaml.load(file, Loader=yaml.FullLoader)
        file.close()
        a = DetailedAirport(icao=a.icao, iata=a.iata, name=a.name, city=a.city, country=a.country, lat=a.lat, lon=a.lon, alt=a.alt)
        a.loadAirlines()
        return a



""" ***************************************************************************


    *********************************************************************** """
class ManagedAirport(DetailedAirport):

    def __init__(self, icao: str, iata: str, name: str, city: str, country: str, lat: float, lon: float):
        DetailedAirport.__init__(self, icao, iata, name, city, country, lat, lon)
        self.destinations = []  # airports
        self.gse = []           # ground support vehicles
        self.parking = []       # parkings
        self.runways = []
        self.runways_arrival = {}
        self.runways_departure = {}
        self.serviceroads = []
        self.QFU = None


    def routeFrom(self, operator: Airline = None):
        """
        Returns list of airports serving this destination.
        """
        pass


    def routeTo(self, operator: Airline = None):
        """
        Returns list of airports served from here.
        """
        pass


    def connections(self):
        """
        Routes from and to this airport
        """


    def airlines(self, codeshare: bool = False):
        """
        Returns airlines operating at this airport.

        :param      codeshare:  Whether to include code-shared airlines
        :type       codeshare:  bool
        """
        pass


    def randomAirline(self):
        pass


    def randomArrival(self, operator: Airline = None):
        pass


    def randomDeparture(self, operator: Airline = None):
        pass


    def randomRotation(self, scheduled: str, operator: Airline = None):
        arrival = self.randomArrival(operator)
        departure = self.randomDeparture(operator)
        rotation = self.mkRotation(scheduled, arrival, departure)


    def randomDepartureAirport(self, operator: Airline = None):
        pass


    def randomArrivalAirport(self, operator: Airline = None):
        pass


    def setQFU(self, wind: float):
        """
        Compute QFU from wind direction.
        QFU is an array with one more runways in use for this wind direction.

        :param      wind:  The wind
        :type       wind:  float
        """
