

class Constant:

    def __init__(self):
        self.parkingRestTime = 10  # minutes

