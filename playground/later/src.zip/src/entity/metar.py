

class Metar:

    def __init__(self, metar: str):
        self.raw = metar

