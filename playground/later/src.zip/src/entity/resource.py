
from reservation import Reservation



class Resource:

    def __init__(self, name, resttime=0):
        self.name = name
        self.resttime = resttime
        self.reservations = []


    def reserve(self, datefrom: str, dateto: str) -> Reservation:
        pass


    def nextAvailable(self) -> str:
        # Returns IS0 8601 date/time of next availability
        pass


