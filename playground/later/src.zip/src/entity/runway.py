from resource import Resource
from airport import Airport


class Runway(Resource):

    def __init__(self, name: str, heading: float, airport: Airport):
        self.heading = heading
        self.slot_size = 5  # min, leave None if not slotted.
        self.airport = airport

