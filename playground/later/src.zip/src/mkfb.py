"""
Make a random flight board from startdate to enddate.
"""

from entity.flightboard import Flightboard
import argparse

def __main__():
    parser = argparse.ArgumentParser(description='Generate flight board.')
    parser.add_argument('startdate', metavar='N', type=str, nargs='+',
                        help='start date for flightboard')
    parser.add_argument('enddate', metavar='N', type=str, nargs='+',
                        help='end date for flightboard')

    args = parser.parse_args()
    print(args.startdate)

    home = ManagedAirport("OTHH")
    flightboard = Flightboard(home)

    out = flightboard.generate()

    print(out)

main()